---
profile: Knife Service Procurement Focus
status: cozzini
focus: procurement
subject: Improving the value of {{company_s}} knife program
---
Hi {{greeting_name}},

I’m Nati Press, National Account Manager at FoodPrep Solutions.

I understand {{company}} currently partners with Cozzini for knife-sharpening services. Given the scale of {{company_s}} operations, I wanted to introduce an opportunity to improve the overall value of your knife program while maintaining a high level of service and product quality across your brands.

FoodPrep Solutions offers:

• Premium-quality knives that support kitchen efficiency and consistency
• No delivery fees or hidden service charges
• Competitive national pricing across all locations
• Dedicated support and consistent service execution nationwide

Beyond the product itself, our goal is to help procurement teams reduce total program costs, improve supplier value, and ensure consistent execution across every restaurant. For organizations with hundreds of locations, even small improvements in program efficiency can create meaningful systemwide savings.

I’d be happy to send a sample set for your team to evaluate. If you see value in what we offer, I’d welcome a brief conversation to discuss how FoodPrep Solutions could support {{company_s}} purchasing and operational objectives.

Thank you for your time and consideration.
